
<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-5 bg-primary text-white text-center">
        <h1>Navigation Settings</h1>
    </div>
    <div class="container mt-3">
        <div class="row">
            <div class="col-sm-3 bg-color p-3">
                <h2>Admin Menu</h2>
            </div>
            <div class="col-sm-9 bg-color p-3">
                <div class="row">
                    <div class="col-sm-12 bg-color p-3">
                        <form action="<?php echo e(route('menus.update',$menu->id)); ?>" method="POST"
                              enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="mb-3 mt-3">
                                <label for="email" class="form-label clearfix">Menu Location</label><br/>
                                <?php if(count($locations) > 0): ?>
                                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-check form-check-inline">
                                            <input type="radio" class="form-check-input" id="location_<?php echo e($location->id); ?>"
                                                   name="location_id" value="<?php echo e($location->id); ?>">
                                            <label class="form-check-label"
                                                   for="radio<?php echo e($location->id); ?>"><?php echo e($location->title); ?></label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3 mt-3 clearfix">
                                <label for="email" class="form-label">Menu Type</label><br/>
                                <?php if(count($types) > 0): ?>
                                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-check form-check-inline">
                                            <input type="radio" class="form-check-input" id="type_<?php echo e($type->id); ?>"
                                                   name="type_id" value="<?php echo e($type->id); ?>">
                                            <label class="form-check-label"
                                                   for="radio<?php echo e($type->id); ?>"><?php echo e($type->title); ?></label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3 mt-3">
                                <label for="email" class="form-label">Menu Name</label>
                                <input type="text" class="form-control" id="menu_name" placeholder="Text Here"
                                       name="menu_name" value="<?php echo e($menu->menu_name); ?>" required>
                            </div>
                            <div class="mb-3 mt-3">
                                <label for="email" class="form-label">Menu Link</label>
                                <input type="text" class="form-control" id="menu_link" placeholder="#" name="menu_link"
                                       value="<?php echo e($menu->menu_link); ?>"
                                       required>
                            </div>
                            <div class="form-check mb-3">
                                <label class="form-check-label">
                                    <input class="form-check-input" type="checkbox" name="new_tab"
                                           value="<?php echo e($menu->new_tab); ?>"> Open in a new
                                    tab
                                </label>
                            </div>
                            <div class="form-check mb-3 pt-5 float-end">
                                <label class="form-check-label">
                                    <button type="submit" class="btn btn-warning" style="width: 100px;">Save</button>
                                </label>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP PROJECTS\laravelnav\resources\views/nav/edit.blade.php ENDPATH**/ ?>